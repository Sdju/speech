---
layout: center
highlighter: shiki
css: unocss
colorSchema: light
transition: fade-out
mdc: true
growSeed: 4
title: The Progressive Path
---

# Vue Renderer

Магия рендеринга своими руками

---
layout: intro
class: pl-40
growSeed: 14
---

# О себе

---

# Vue renderer
- Актуальность

---

# Рендереры

---

# vue core
- @vue/runtime-core

---

# Vue DOM
- createApp
- createSSRApp

---

# Vue DOM
- createApp
- createSSRApp

---

# Наиболее простой рендерер
- @vue/runtime-test

---

# Vue custom renderer

---

# Vue custom renderer (схема)

---

# Простейший DOM-рендерер

```html
html base example
```

---

# Простейший DOM-рендерер

```html
html base example
```

---

# Подготовка

```ts
function noop(fn: string): any {
  throw Error(`no-op: ${fn}`)
}

const nodeOps = {
  patchProp: () => noop('patchProp'),
  insert: () => noop('insert'),
  remove: () => noop('remove'),
  createElement: () => noop('createElement'),
  createText: () => noop('createText'),
  createComment: () => noop('createComment'),
  setText: () => noop('setText'),
  setElementText: () => noop('setElementText'),
  parentNode: () => noop('parentNode'),
  nextSibling: () => noop('nextSibling'),
  querySelector: () => noop('querySelector'),
  setScopeId: () => noop('setScopeId'),
  cloneNode: () => noop('setScopeId'),
  insertStaticContent: () => noop('insertStaticContent'),
}
```

---

#  createText

`createText` - Создаем текстовый элемент

- `text: string` - текст элемента

```js
({
  // ...
  
  createText: (text) => document.createTextNode(text),
  
  // ...
})
```

---

# createElement

`createElement` - Создаем элемент

- `type: string` - тип элемента
- `namespace?: "svg" | "mathml" | undefined`
- `isCustomizedBuiltIn?: string` - `is` для веб-компонентов
- `vnodeProps?: Record<string, any> | null` - пропсы

```js
({
  // ...
  
  createElement: (tag) => document.createElement(tag),
  
  // ...
})
```

---

# insert

`insert` - вставка дочернего элемента в родительский
- `child` - кого
- `parent` - куда
- `anchor` - перед каким элементом вставка

```js
({
  // ...
  
  insert: (child, parent, anchor) => {
    parent.insertBefore(child, anchor || null)
  }
  
  // ...
})
```

---

# insert

`insert` - вставка дочернего элемента в родительский
- `child` - кого
- `parent` - куда
- `anchor` - перед каким элементом вставка

```js
({
  // ...
  
  insert: (child, parent, anchor) => {
    parent.insertBefore(child, anchor || null)
  }
  
  // ...
})
```

---

# setText/setElementText

```js
({
  // ...
  
  setText: (node, text) => {
    node.nodeValue = text
  },

  setElementText: (el, text) => {
    el.textContent = text
  },
  
  // ...
})
```

---

# nextSibling/parentNode

```js
({
  // ...
  
  parentNode: node => node.parentNode,

  nextSibling: node => node.nextSibling,
  
  // ...
})
```

---

# patchProp

```ts
({
  // ...
    patchProp(
      el: HostElement,
      key: string,
      prevValue: any,
      nextValue: any,
      namespace?: ElementNamespace,
      prevChildren?: VNode<HostNode, HostElement>[],
      parentComponent?: ComponentInternalInstance | null,
      parentSuspense?: SuspenseBoundary | null,
      unmountChildren?: UnmountChildrenFn,
  ): void {
    // ...
  }
  // ...
})
```

---

# patchProp simple

```ts
({
  // ...
    patchProp(
      el: Element,
      key: string,
      prevValue: any,
      nextValue: any,
  ): void {
    if (key === 'class') {
      el.className = nextValue
      return
    }
    if (key.startsWith('on')) {
      // ...
    }
    if (nextValue === null) {
      el.removeAttribute(key)
    }
    el.setAttribute(key, nextValue)
  }
  // ...
})
```

---

# Тестируем

```html
<!-- Описание базового компонента -->
```

---

# Создаем рендерер

```ts
export const createApp = (rootComponent: Component, rootProps?: Record<string, unknown> | null) => {
  const renderer = createRenderer(rendererOptions)

  const app = renderer.createApp(rootComponent, rootProps)
  const { mount } = app

  app.mount = (doc: HTMLElement) => {
    return mount(doc)
  }
  
  return app
}
```

---

# Подключаем рендерер

```ts
import { createApp } from './renderer-react/renderer'
import App from './App.vue'

const app = createApp(App)
app.mount(document.querySelector('#react'))
```

---

# Запуск

> Вставить скрин рендера

---

# Модифицируем

```vue
<!-- Пример с добавлением v-if -->
```

> Скрин с ошибкой noop

---

# Модифицируем

```vue
<!-- Пример с добавлением v-if -->
```

---

# createComment

```ts
({
  // ...
  
  createComment: text => document.createComment(text),
  
  // ...
})
```

---

# remove

```ts
({
  // ...
  
  remove: (child) => {
    child.parentNode?.removeChild(child)
  }

  // ...
})
```

---

# Все заработало

> Скрин как все заработало

---

# querySelector / setScopeId

```ts
({
  // ...
  
  querySelector: selector => document.querySelector(selector),

  setScopeId(el, id) {
    el.setAttribute(id, '')
  },
  
  // ...
})
```

---

# cloneNode / insertStaticContent

> Только для @vue/compiler-dom

```ts
({
  // ...

  cloneNode: () => noop('setScopeId'),
  insertStaticContent: () => noop('insertStaticContent'),

  // ...
})
```

---

# Кто использует?

---

# TresJS

---

# nativescript-vue

---

# Что можно сделать самому?

- Рендерер для PDF
- Рендерер для Canvas
- Рендерер для React...

# Vue Renderer to React

- DOM -> React.createElement
- mount -> React.

Проблемы:
- В хуке `mounted` мы получим в `ref` наш элемент прослойки между React и Vue
- В момент хука `mounted` реальная DOM нода еще не создана

---

# Vue Vapor

> Не завершен и находится в фазе активной разработки

На данный момент в способа использования Custom Renderer во Vue Vapor - нет

---