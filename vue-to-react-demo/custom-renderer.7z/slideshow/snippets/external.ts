/* eslint-disable no-console */

// #region snippet
function hello() {
  console.log('Hello from snippets/external.ts')
}
// #endregion snippet

export default hello
