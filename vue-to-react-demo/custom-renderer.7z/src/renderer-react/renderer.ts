import {type Component, createRenderer,} from 'vue'
import {createRoot} from 'react-dom/client';
import {Fragment} from 'react/jsx-runtime';
import {createElement, useRef, useState} from 'react';

function noop(fn: string): never {
  throw Error(`no-op: ${fn}`)
}

const propRename: Record<string, string> = {
  'xmlns:xlink': 'xmlnsXlink',
  'class': 'className',
  'onUpdate:modelValue': 'onChange',
  'modelValue': 'value'
}

function mapChild(child) {
  if ('comment' in child) {
    return null
  }
  if ('text' in child) {
    return child.text
  }
  return createElement(child.render)
}

let id = 0

function createNode(tag: string) {
  const { [tag]: render } = {
    [tag]: () => {
      const [props, setProps] = useState(element.props)
      const [children, setChildren] = useState(element.children)
      element.setChildren = setChildren
      element.props = props
      element.setProps = setProps

      return createElement(tag, { ...props, ref: element.refSetter }, ...children.map(mapChild))
    }
  }

  const element = {
    id: id++,
    props: {} as Record<string, unknown>,
    refSetter: {
      set current(newRef) {
        element.ref = newRef
      },
      get current() {
        return element.ref
      }
    },
    addEventListener(event, listener, flags) {
      console.log(event, listener, flags)
    },
    removeEventListener(event, listener, flags) {
      console.log(event, listener, flags)
    },
    setProps(newProps: Record<string, unknown>) {
      element.props = newProps
    },
    children: [] as unknown[],
    setChildren(newChildren: unknown[]) {
      element.children = newChildren
    },
    ref: null as unknown,
    parent: null,
    render
  }
  return element
}

export const createApp = (rootComponent: Component, rootProps?: Record<string, unknown> | null) => {
  const renderer = createRenderer({
    patchProp(el, key, prevVal, nextVal) {
      const realKey = propRename[key] ?? key
      el.setProps({...el.props, [realKey]: nextVal})
    },

    insert(child, parent, anchor) {
      child.parent = parent

      if (anchor) {
        const id = parent.children.indexOf(anchor)
        parent.children.splice(id, 0, child)
        parent.setChildren([...parent.children])
        return
      }

      parent.children.push(child)
      parent.setChildren([...parent.children])
    },

    createElement(tag) {
      return createNode(tag)
    },

    createText(text: string) {
      return {
        text,
        parent: null,
      }
    },

    parentNode(node) {
      return node.parent
    },

    createComment(text) {
      return {
        comment: text,
        parent: null
      }
    },

    setText(node, text) {
      node.text = text
      node.parent.setChildren([...node.parent.children])
    },

    setElementText(node, text) {
      node.setChildren([{
        text,
        parent: node,
      }])
    },

    nextSibling(node) {
      const pos = node.parent?.children.indexOf(node)
      return node.parent?.children[pos + 1]
    },

    setScopeId(node, id) {
      node.setProps({...node.props, [id]: ''})
    },

    remove(node) {
      const pos = node.parent.children.indexOf(node)
      node.parent.children.splice(pos, 1)
      node.parent.setChildren([...node.parent.children])
      node.parent = null
    },

    // для телепорта
    querySelector() {
      noop('querySelector')
    },

    insertStaticContent() {
      noop('insertStaticContent')
    },

    cloneNode() {
      noop('cloneNode')
    },
  })

  const app = renderer.createApp(rootComponent, rootProps)
  const { mount } = app

  app.mount = (doc: HTMLElement): any => {
    const container = createNode('root')
    container.render = () => {
      const [children, setChildren] = useState(container.children)
      container.setChildren = setChildren

      return createElement(Fragment, null, ...children.map(mapChild))
    }
    const proxy = mount(container)

    createRoot(doc).render(createElement(container.render))

    return proxy
  }
  return app
}
